<div class="row clearfix">
    <div class="col-lg-12 col-md-12">
        <div class="card planned_task">
            <div class="header">
                <h2></h2>
            </div>
            <div class="body">
                <a href="http://localhost/hms/home-about-us.php"> Cleck me to run </i></a>
            </div>
        </div>
    </div>
</div>