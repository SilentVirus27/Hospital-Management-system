<?php
  include("include/admin-header.php");
  ?>
<!--MAIN Content-->
            <div class="row clealfix">
                <div class="col-lg-12 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2>Casebook</h2>
                        </div>
                        <div class="body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">Ref Doctor :</li>
                                <li class="list-group-item">Allergy :</li>
                                <li class="list-group-item">Vaccination :</li>
                                <li class="list-group-item">Genetic Diseases :</li>
                                <li class="list-group-item">Current Diseases :</li>
                                <li class="list-group-item">Health Effect :</li>
                                <li class="list-group-item">Sergical History :</li>
                                <li class="list-group-item">Social History :</li>
                                <li class="list-group-item">Mental History :</li>
                                <li class="list-group-item">NewBorn Complication :</li>
                                <li class="list-group-item">Pregnancy/Period Details :</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
<?php
  include("include/admin-footer.php");
  ?>